#!/usr/bin/python
# -*-coding:UTF-8-*-
# encoding=utf8
from matplotlib.colors import LogNorm
import pylab
from pylab import hist2d, colorbar
import matplotlib.pyplot as plt
from com.office.util.excelUtil import read
from com.office.util import fileUtil
import os
srcFiles =  fileUtil.getFiles("yaohao")
    
x = []
y = []
for srcFile in srcFiles[:5]:
    print "parse",srcFile
    srcData = read(os.path.join("yaohao", srcFile));
    src=[]
    d = {}
    for data in srcData[0]:
        datar = int(data)/100000000000
        if not d.has_key(datar):
            d[datar] = 0
        d[datar] += 1

    for key in d:
        y.append(d[key])
        x.append(key)

hist2d(x, y, bins=100, norm=LogNorm())
colorbar()
pylab.xlabel(u'中签号码的开头两位数')
pylab.ylabel(u'中签个数')
pylab.title(u"摇号散点图")
plt.show()