#!/usr/bin/python
# -*-coding:UTF-8-*-
# encoding=utf8
import matplotlib.pyplot as plt
from com.office.util.excelUtil import read
from com.office.util import fileUtil
import os, random
srcFiles =  fileUtil.getFiles("yaohao")
    
plt.figure(figsize=(8, 5), dpi=150)
axes = plt.subplot(111)
typelist = []
descList= []
for srcFile in srcFiles[:5]:
    x = []
    y = []
    print "parse",srcFile
    srcData = read(os.path.join("yaohao", srcFile));
    src=[]
    d = {}
    for data in srcData[0]:
        datar = int(data)/100000000000
        if not d.has_key(datar):
            d[datar] = 0
        d[datar] += 1

    for key in d:
        y.append(d[key])
        x.append(key)
        
    c = '#%x%x%x'%(random.randint(16, 255), random.randint(16, 255), random.randint(16, 255))
    print c
    typelist.append(plt.scatter(x, y, s=20, c=c))
    descList.append(srcFile);
    
plt.legend(typelist,descList, loc='upper center', fontsize='xx-small', title='iTitle')
plt.xlabel(u'中签号码的开头两位数')
plt.ylabel(u'中签个数')
plt.title(u"摇号散点图")
plt.show()



