#!/usr/bin/python
# -*-coding:UTF-8-*-
# encoding=utf8
import numpy
import pylab
from com.office.util.excelUtil import read
from matplotlib import rcParams
pylab.figure(figsize=(9,6), dpi=120,edgecolor='y')
srcData = read("resulttiezi.xls");
keylist=srcData[0]
keylist.insert(0, u" ")
keylist.append(u" ")
print keylist
vallist=srcData[1]
vallist.insert(0, 0.0001);
vallist.append(0.0001)
print vallist
barwidth=0.2
xVal=numpy.arange(len(keylist))/3.0
print xVal
pylab.xticks(xVal+barwidth,keylist,rotation=87)
pylab.bar(xVal+barwidth,vallist,width=barwidth,color='#abcdef', edgecolor='#ffffff')
pylab.title(u'测试分析图', loc='center', fontdict={'fontsize': rcParams['axes.titlesize'],
         'verticalalignment': 'baseline'})
pylab.show()
