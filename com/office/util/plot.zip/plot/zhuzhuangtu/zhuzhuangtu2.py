#!/usr/bin/python
# -*-coding:UTF-8-*-
# encoding=utf8
import numpy
import pylab
from com.office.util.excelUtil import read
import os
from com.office.util import fileUtil
srcFiles =  fileUtil.getFiles("../sandiantu/yaohao")
d = {}
for srcFile in srcFiles[:5]:
    srcData = read(os.path.join("../sandiantu/yaohao", srcFile));
    src=[]
    print len(srcData[0])
    for data in srcData[0]:
        datar = int(data)/100000000000
        if not d.has_key(datar):
            d[datar] = 0
        d[datar] += 1

keylist = []
vallist = []
vallist2 = []
vallist3 = []
count = 10
for key in d:
    if count <0:
        break
    else:
        count-=1
    vallist.append(d[key])
    vallist2.append(d[key]/2)
    vallist3.append(d[key]/3)
    if key < 10:
        key = "0%d"%key
    else:
        key = str(key) 
    keylist.append(key)
barwidth=0.2
xVal=numpy.arange(len(keylist))
pylab.xticks(xVal+barwidth,keylist,rotation=79)
    
type1 = pylab.bar(xVal+barwidth,vallist,width=barwidth,color='y', edgecolor='#ffffff')
type2 = pylab.bar(xVal+barwidth+0.1,vallist2,width=barwidth,color='b', edgecolor='#ffffff')
type3 = pylab.bar(xVal+barwidth+0.2,vallist3,width=barwidth,color='r', edgecolor='#ffffff')

for x,y in zip(xVal,vallist):
    pylab.text(x+barwidth, y+0.3, y, ha='left', va= 'bottom')

pylab.legend((type1,type2,type3),("hehe","heihei","haha"), loc=0, fontsize='x-small', title='iTitle')
pylab.title(u'摇号分布')
pylab.xlabel(u'中签号码的开头两位数')
pylab.ylabel(u'中签个数')
pylab.show()
